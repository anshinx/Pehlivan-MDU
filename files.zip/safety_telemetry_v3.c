/* ===========================================================================
 * PEHLIVAN TEAM -- Guvenlik & Telemetri Sistemi
 * Shell Eco-Marathon 2026
 * v3.0 -- Gemini Audit Duzeltmeleri
 *
 * v2 -> v3 Duzeltmeler:
 *   [G1] Safety_Check: hallval volatile race condition -- yerel kopya ile okuma
 *   [G2] acceltop int -> int32_t (motor_driver_v4.c'de de guncellendi)
 *   [G3] Failsafe hysteresis recovery:
 *          FS_WARNING ve FS_REDUCED_POWER icin sensör duzeldikten
 *          sonra otomatik geri donus eklendi (hysteresis + timer ile).
 *          FS_HALT ve FS_PANIC kasitli olarak hic geri donmez -- reset gerekir.
 *
 * Gemini'nin yanlis buldugu ama dogru olan seyler:
 *   - SW_Watchdog_Feed: Motor_Loop adim 2'de zaten cagiriliyordu
 *   - ADC kilitlenme: HAL_ADC_PollForConversion 10ms timeout var, deadlock yok
 * ===========================================================================*/

#include "safety_telemetry.h"
#include <string.h>
#include <stdio.h>

/* ===========================================================================
 * HANDLE'LAR
 * ===========================================================================*/
extern CRC_HandleTypeDef   hcrc;
extern UART_HandleTypeDef  huart4;
extern UART_HandleTypeDef  huart2;

/* ===========================================================================
 * IC DURUM DEGISKENLERI
 * ===========================================================================*/
static FailsafeState_t  currentState  = FS_NORMAL;
static uint16_t         fsReasonMask  = FSR_NONE;

/* Kara kutu dongüsel buffer */
static LogRecord_t  logQueue[LOG_QUEUE_SIZE];
static uint8_t      logHead  = 0;
static uint8_t      logTail  = 0;
static uint8_t      logCount = 0;

/* Yazilim watchdog */
static volatile uint32_t swWdgLastFeed = 0;
static volatile bool     swWdgEnabled  = false;

/* Sensor timeout takibi */
static uint32_t lastHallChange_ms = 0;
static uint32_t lastADCRead_ms    = 0;
#define HALL_TIMEOUT_MS   2000u
#define ADC_TIMEOUT_MS    500u

/* ===========================================================================
 * [G3] FAILSAFE RECOVERY -- Hysteresis ile otomatik geri donus
 *
 * Sorun: Anlık bir sicaklik/voltaj dalgalanmasi arabaci FS_REDUCED_POWER'a
 * dusuruyorsa ve sensör normale donerse araç yavaş gitmeye devam eder.
 *
 * Cozum:
 *   - FS_WARNING ve FS_REDUCED_POWER icin recovery timer tutulur.
 *   - Hata kosulu belirli sure boyunca gecerse (RECOVERY_HOLD_MS) durum
 *     bir alt seviyeye duser.
 *   - FS_HALT ve FS_PANIC hic otomatik geri donmez -- reset gerekir.
 *
 * Hysteresis parametreleri:
 *   RECOVERY_HOLD_MS: hata kosulunun kac ms boyunca gecmis olmasi gerekir
 *   Ornek: 3000ms boyunca sicaklik warn esiginin altinda kalirsa
 *          FS_WARNING -> FS_NORMAL'e doner.
 *
 * Dikkat: Geri donus sadece o hata sebebinin gecmesine bakar.
 * Birden fazla sebep varsa hepsinin gecmesi gerekir.
 * ===========================================================================*/
#define RECOVERY_HOLD_MS   3000u   /* 3 saniye boyunca hata yoksa geri don */

static uint32_t recoveryStartTime = 0;   /* Hata gecince sayac baslangici    */
static bool     recoveryActive    = false; /* Geri donus sayaci aktif mi?    */

/* ===========================================================================
 * CRC16 -- STM32G474 Donanimsal CRC
 * ===========================================================================*/
uint16_t Calc_CRC16(const uint8_t *data, uint16_t len) {
    __HAL_CRC_DR_RESET(&hcrc);

    uint16_t i;
    uint32_t word;
    for (i = 0; i + 3 < len; i += 4) {
        word = ((uint32_t)data[i]   << 24) |
               ((uint32_t)data[i+1] << 16) |
               ((uint32_t)data[i+2] <<  8) |
               ((uint32_t)data[i+3]);
        HAL_CRC_Accumulate(&hcrc, &word, 1);
    }
    uint32_t remain = 0;
    uint8_t  shift  = 24;
    for (; i < len; i++, shift -= 8) {
        remain |= ((uint32_t)data[i] << shift);
    }
    if (i > (len & ~3u)) {
        HAL_CRC_Accumulate(&hcrc, &remain, 1);
    }
    return (uint16_t)(hcrc.Instance->DR & 0xFFFFu);
}

/* ===========================================================================
 * KARA KUTU -- LOG KUYRUĞA EKLE (Non-blocking)
 * ===========================================================================*/
void BlackBox_Log(FailsafeReason_t reason) {
    LogRecord_t rec;

    rec.magic        = 0x0E47u;
    rec.timestamp_ms = HAL_GetTick();
    rec.fs_state     = (uint8_t)currentState;
    rec.fs_reason    = (uint16_t)(fsReasonMask | reason);
    rec.gaz_x10      = (int16_t)(gaz     * 10);
    rec.accel_x10    = (int16_t)(Accel   * 10);
    rec.temp_x10     = (int16_t)(OrtTemp * 10.0f);
    rec.volt_x10     = (int16_t)(OrtVolt * 10.0f);
    rec.curr_x10     = (int16_t)(OrtCurr * 10.0f);
    rec.rpm_x10      = (int16_t)(devirdak * 10.0f);
    rec.hall         = hallval;
    rec.flags        = (uint8_t)(
                           (DirF      ? 0x01u : 0u) |
                           (BrakeF    ? 0x02u : 0u) |
                           (hareket   ? 0x04u : 0u) |
                           (gazizin   ? 0x08u : 0u) |
                           (panicF    ? 0x10u : 0u) |
                           (ilkkontak ? 0x20u : 0u)
                       );
    rec.crc16 = Calc_CRC16((uint8_t*)&rec, sizeof(LogRecord_t) - 2u);

    if (logCount < LOG_QUEUE_SIZE) {
        logQueue[logHead] = rec;
        logHead  = (logHead + 1u) % LOG_QUEUE_SIZE;
        logCount++;
    } else {
        logQueue[logHead] = rec;
        logHead  = (logHead + 1u) % LOG_QUEUE_SIZE;
        logTail  = (logTail + 1u) % LOG_QUEUE_SIZE;
    }
}

/* ===========================================================================
 * KARA KUTU -- UART4'E YAZ (Non-blocking, her cagirida 1 kayit)
 * Motor_Loop() sonunda cagir.
 * ===========================================================================*/
void BlackBox_Flush(void) {
    if (logCount == 0u) return;

    static uint8_t txBuf[sizeof(LogRecord_t) + 2u];
    LogRecord_t *rec = &logQueue[logTail];

    txBuf[0] = 0x50u;  /* 'P' -- senkronizasyon */
    txBuf[1] = 0x0Eu;
    memcpy(&txBuf[2], rec, sizeof(LogRecord_t));

    if (HAL_UART_Transmit_IT(&huart4, txBuf,
                              sizeof(LogRecord_t) + 2u) == HAL_OK) {
        logTail  = (logTail + 1u) % LOG_QUEUE_SIZE;
        logCount--;
    }
}

/* ===========================================================================
 * TELEMETRI -- USART2 ASCII CIKIS
 * Format: $PHL,<tick>,<gaz>,<accel>,<T>,<V>,<A>,<rpm>,<state>,<hall>,<reason>
 * Non-blocking IT versiyonu.
 * ===========================================================================*/
static char     uartTxBuf[96];
static volatile bool uartBusy = false;

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) { uartBusy = false; }
}

void Telemetry_SendUART(void) {
    if (uartBusy) return;

    int temp_i = (int)(OrtTemp  * 10.0f);
    int volt_i = (int)(OrtVolt  * 10.0f);
    int curr_i = (int)(OrtCurr  * 10.0f);
    int rpm_i  = (int)(devirdak);

    int len = snprintf(uartTxBuf, sizeof(uartTxBuf),
        "$PHL,%lu,%d,%d,%d.%d,%d.%d,%d.%d,%d,%d,%d,%d\r\n",
        HAL_GetTick(),
        gaz, Accel,
        temp_i / 10, temp_i % 10,
        volt_i / 10, volt_i % 10,
        curr_i / 10, curr_i % 10,
        rpm_i,
        (int)currentState,
        hallval,
        (int)fsReasonMask
    );

    if (len > 0 && len < (int)sizeof(uartTxBuf)) {
        uartBusy = true;
        HAL_UART_Transmit_IT(&huart2, (uint8_t*)uartTxBuf, (uint16_t)len);
    }
}

/* ===========================================================================
 * YAZILIM WATCHDOG
 * ===========================================================================*/
void SW_Watchdog_Feed(void) {
    swWdgLastFeed = HAL_GetTick();
    swWdgEnabled  = true;
}

void SW_Watchdog_Check(void) {
    if (!swWdgEnabled) return;
    if ((HAL_GetTick() - swWdgLastFeed) > SW_WATCHDOG_TIMEOUT_MS) {
        Safety_SetState(FS_HALT, FSR_SW_WATCHDOG);
    }
}

/* ===========================================================================
 * FAILSAFE STATE MACHINE
 *
 * Gecis kurali: Bir ust seviyeye (daha kisitlayici) her zaman gecilir.
 * Geri donus: FS_WARNING ve FS_REDUCED_POWER icin hysteresis recovery ile.
 *             FS_HALT ve FS_PANIC asla otomatik geri donmez.
 * ===========================================================================*/
void Safety_SetState(FailsafeState_t newState, FailsafeReason_t reason) {
    if (newState <= currentState) return;

    fsReasonMask |= (uint16_t)reason;
    currentState  = newState;

    /* Yeni hatada recovery sayacini sifirla */
    recoveryActive    = false;
    recoveryStartTime = 0;

    BlackBox_Log(reason);

    switch (currentState) {
        case FS_WARNING:
            BlinkStat = 1;
            break;
        case FS_REDUCED_POWER:
            if (gaz > (maxpwm * 60 / 100)) { gaz = maxpwm * 60 / 100; }
            BlinkStat = 2;
            break;
        case FS_LIMP_HOME:
            if (gaz > (maxpwm * 30 / 100)) { gaz = maxpwm * 30 / 100; }
            BlinkStat = 2;
            break;
        case FS_HALT:
        case FS_PANIC:
            gaz  = 0;
            acil = true;
            deadtime();
            BlinkStat = 2;
            break;
        default:
            break;
    }
}

/* ===========================================================================
 * [G3] FAILSAFE RECOVERY -- Sensör duzeldikten sonra geri donus
 *
 * Hangi durumlar recover olabilir:
 *   FS_WARNING       -> FS_NORMAL        (sicaklik/voltaj uzun sure normal)
 *   FS_REDUCED_POWER -> FS_WARNING       (asiri sicaklik gecti)
 *
 * Hangi durumlar recover OLAMAZ:
 *   FS_LIMP_HOME     -- Hall timeout veya ciddi akim hatasi -- reset gerekir
 *   FS_HALT          -- Kritik hata -- reset gerekir
 *   FS_PANIC         -- Fiziksel panik butonu -- reset gerekir
 *
 * Mantik:
 *   1) Hata kosullari gecmis mi kontrol et (sicaklik/voltaj normal mi?)
 *   2) Gectiyse sayac baslat
 *   3) RECOVERY_HOLD_MS boyunca hata yoksa bir adim geri dön
 *   4) Hata tekrar gelirse sayaci sifirla
 * ===========================================================================*/
static void Safety_RecoveryCheck(uint32_t now) {

    /* FS_HALT ve FS_PANIC hic recover olmaz */
    if (currentState >= FS_HALT) return;
    /* FS_LIMP_HOME da recover olmaz -- ciddi hata */
    if (currentState == FS_LIMP_HOME) return;
    /* FS_NORMAL'de yapacak bir sey yok */
    if (currentState == FS_NORMAL) return;

    /* Hata kosullari hala devam ediyor mu? */
    bool stillFaulty = false;

    if (OrtTemp > warntemp)                 stillFaulty = true;
    if (OrtVolt < pilmin && OrtVolt > 1.0f) stillFaulty = true;
    if (OrtVolt > pilmax)                   stillFaulty = true;
    if (OrtCurr > maxsystemamp)             stillFaulty = true;
    if (panicF)                             stillFaulty = true;

    if (stillFaulty) {
        /* Hata sürüyor -- sayaci sifirla */
        recoveryActive    = false;
        recoveryStartTime = 0;
        return;
    }

    /* Hata gecti -- sayaci baslat veya kontrol et */
    if (!recoveryActive) {
        recoveryActive    = true;
        recoveryStartTime = now;
        return;
    }

    /* RECOVERY_HOLD_MS boyunca hata yoksa bir adim geri dön */
    if ((now - recoveryStartTime) >= RECOVERY_HOLD_MS) {
        recoveryActive = false;

        /* Bir adim geri dön (tek atlamak yapma -- safety) */
        if (currentState == FS_WARNING) {
            currentState = FS_NORMAL;
            BlinkStat    = 1;
            BlackBox_Log(FSR_NONE);   /* Recovery kaydi */
        } else if (currentState == FS_REDUCED_POWER) {
            currentState = FS_WARNING;
            BlinkStat    = 1;
            BlackBox_Log(FSR_NONE);
        }
        /* fsReasonMask kasitli temizlenmez -- hangi hatanin oldugunun kaydı kalir */
    }
}

uint8_t Safety_GetMaxPWM(void) {
    switch (currentState) {
        case FS_NORMAL:        return maxpwm;
        case FS_WARNING:       return maxpwm;
        case FS_REDUCED_POWER: return (uint8_t)(maxpwm * 60u / 100u);
        case FS_LIMP_HOME:     return (uint8_t)(maxpwm * 30u / 100u);
        case FS_HALT:
        case FS_PANIC:         return 0u;
        default:               return 0u;
    }
}

FailsafeState_t Safety_GetState(void) { return currentState; }

const char* Safety_GetStateName(void) {
    switch (currentState) {
        case FS_NORMAL:        return "NORMAL";
        case FS_WARNING:       return "WARNING";
        case FS_REDUCED_POWER: return "REDUCED";
        case FS_LIMP_HOME:     return "LIMP";
        case FS_HALT:          return "HALT";
        case FS_PANIC:         return "PANIC";
        default:               return "UNKNOWN";
    }
}

/* ===========================================================================
 * ANA GUVENLIK KONTROLU
 *
 * [G1] BUG FIX: hallval volatile race condition cozümü.
 *   Eski kod: if (hareket && hallval == ihallval)
 *   Sorun: Safety_Check calisirken EXTI kesmesi hallval'i degistirebilir.
 *   Cortex-M4 uint8_t okumasi atomik olsa da, karmasik kosullarda
 *   tutarli snapshot almak iyi pratiktir.
 *   Cozum: hallval ve ihallval'in anlık kopyalari alinir, tüm kontroller
 *   bu kopyalar üzerinden yapilir.
 * ===========================================================================*/
FailsafeState_t Safety_Check(void) {
    uint32_t now = HAL_GetTick();

    /* [G1] Volatile degiskenlerin anlık kopyalari -- tutarli okuma */
    uint8_t  hall_snap  = hallval;    /* atomic uint8_t okuma -- kopya yeterli */
    uint8_t  ihall_snap = ihallval;
    bool     hareket_snap = hareket;

    /* Sicaklik */
    if (OrtTemp > maxtemp) {
        Safety_SetState(FS_HALT, FSR_OVERTEMP_CRIT);
    } else if (OrtTemp > warntemp) {
        if (currentState < FS_WARNING)
            Safety_SetState(FS_WARNING, FSR_OVERTEMP_WARN);
        if (OrtTemp > (warntemp + (maxtemp - warntemp) * 0.7f))
            Safety_SetState(FS_REDUCED_POWER, FSR_OVERTEMP_WARN);
    }

    /* Voltaj */
    if (OrtVolt < pilmin && OrtVolt > 1.0f) {
        Safety_SetState(FS_LIMP_HOME, FSR_UNDERVOLT);
    }
    if (OrtVolt > pilmax) {
        Safety_SetState(FS_HALT, FSR_OVERVOLT);
    }

    /* Akim */
    if (OrtCurr > maxsystemamp) {
        Safety_SetState(FS_HALT, FSR_OVERCURR_SYS);
    }
    if (OrtCurr > maxstartamp && !hareket_snap) {
        Safety_SetState(FS_REDUCED_POWER, FSR_OVERCURR_START);
    }

    /* Hall sensor timeout -- [G1] snapshot'lar kullaniliyor */
    if (hareket_snap && hall_snap == ihall_snap) {
        if ((now - lastHallChange_ms) > HALL_TIMEOUT_MS) {
            Safety_SetState(FS_LIMP_HOME, FSR_HALL_TIMEOUT);
        }
    } else {
        lastHallChange_ms = now;
    }

    /* ADC timeout */
    if ((now - lastADCRead_ms) > ADC_TIMEOUT_MS) {
        Safety_SetState(FS_WARNING, FSR_ADC_TIMEOUT);
    }

    /* PANIC pin */
    if (panicF) {
        Safety_SetState(FS_PANIC, FSR_PANIC_PIN);
    }

    /* Yazilim watchdog */
    SW_Watchdog_Check();

    /* [G3] Recovery kontrolu -- sensör duzeldikten sonra geri donus */
    Safety_RecoveryCheck(now);

    return currentState;
}

void Safety_ADCUpdated(void) {
    lastADCRead_ms = HAL_GetTick();
}

/* ===========================================================================
 * BASLAMA
 * Motor_Init() icinden cagirilir.
 * ===========================================================================*/
void Safety_Init(void) {
    currentState      = FS_NORMAL;
    fsReasonMask      = FSR_NONE;
    logHead           = 0;
    logTail           = 0;
    logCount          = 0;
    swWdgEnabled      = false;
    recoveryActive    = false;
    recoveryStartTime = 0;
    lastADCRead_ms    = HAL_GetTick();
    lastHallChange_ms = HAL_GetTick();

    BlackBox_Log(FSR_NONE);
}
